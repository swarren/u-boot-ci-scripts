# Copyright (c) 2015 Stephen Warren
# Copyright (c) 2015-2016, NVIDIA CORPORATION. All rights reserved.
#
# SPDX-License-Identifier: GPL-2.0

# Logic to interact with the sandbox port of U-Boot, running as a sub-process.

import time
from u_boot_spawn import Spawn
from u_boot_console_base import ConsoleBase

class ConsoleSandbox(ConsoleBase):
    '''Represents a connection to a sandbox U-Boot console, executed as a sub-
    process.'''

    def __init__(self, log, config):
        '''Initialize a U-Boot console connection.

        log: A multiplexed_log::Logfile instance.
        config: A "configuration" object as defined in conftest.py.'''

        super(ConsoleSandbox, self).__init__(log, config, max_fifo_fill=1024)

    def get_spawn(self):
        '''Create and return a new "spawn" object that is attached to a
        freshly invoked U-Boot sandbox process.'''

        return Spawn([self.config.build_dir + '/u-boot'])

    def kill(self, sig):
        '''Send a specific Unix signal to the sandbox process.'''

        self.ensure_spawned()
        self.log.action('kill %d' % sig)
        self.p.kill(sig)

    def validate_exited(self):
        '''Validate that the sandbox process has exited.'''

        p = self.p
        self.p = None
        for i in xrange(100):
            ret = not p.isalive()
            if ret:
                break
            time.sleep(0.1)
        p.close()
        return ret
